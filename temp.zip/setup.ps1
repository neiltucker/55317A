:: Create a folder named C:\Classfiles\Tools
if not exist "C:\Classfiles\Tools" mkdir "C:\Classfiles\Tools"

:: Download addons.zip
powershell -Command "(New-Object System.Net.WebClient).DownloadFile('https://github.com/neiltucker/55317a/raw/main/addons.zip', 'C:\Classfiles\Tools\addons.zip')"

:: Step 3: Copy the addons.zip file to that folder
:: copy "C:\Classfiles\Tools\addons.zip" "C:\Classfiles\Tools"

:: Step 4: Extract all the files in the Addons.zip folder
powershell -Command "Expand-Archive -Path 'C:\Classfiles\Tools\addons.zip' -DestinationPath 'C:\Classfiles\Tools'"

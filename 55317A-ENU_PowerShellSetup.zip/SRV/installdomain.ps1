#  Install Contoso.com Domain
Get-DNSClientServerAddress | Where {$_.InterfaceAlias -like "Ethernet*"} | Set-DNSClientServerAddress -ServerAddresses ("192.168.10.100","192.168.20.100")
cls
echo "Install Contoso.com Domain"
$SecurePassword = ConvertTo-SecureString -AsPlainText Pa$$w0rdPa$$w0rd -Force
Install-WindowsFeature -Name AD-Domain-Services �IncludeManagementTools
Import-Module AddsDeployment
Install-ADDSForest -DomainName "contoso.com" -InstallDNS -DatabasePath "C:\Windows\NTDS" -SysvolPath "C:\Windows\SYSVOL" -LogPath "C:\Windows\LOGS" -SafeModeAdministratorPassword $SecurePassword -Force


-- Work with UNION and JOIN statements using the Sales and AdventureWorks2019 databases
-- The AdventureWorks2019 database should already be available from a previous step.  Create Sales with the following steps
USE master
GO
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'sales')
BEGIN
    DROP DATABASE sales
END
CREATE DATABASE sales
GO
-- Import sales figures for Canada, Mexico and USA into separate tables
USE sales
GO
SELECT *
INTO cansales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_can.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
SELECT *
INTO mexsales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_mex.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
SELECT *
INTO usasales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_usa.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
-- Query the sales figures for each region individually and as a single result set using the UNION statement
SELECT * FROM cansales
GO
SELECT * FROM mexsales
GO
SELECT * FROM usasales
GO
SELECT UPPER(SubString(StoreID,1,3)) as 'Location', CustomerID, SalesDate as 'Date', CAST(Sales as FLOAT) as Sales
FROM cansales
UNION
SELECT UPPER(SubString(StoreID,1,3)) as 'Location', CustomerID, SalesDate as 'Date', CAST(Sales as FLOAT) as Sales
FROM mexsales
UNION
SELECT UPPER(SubString(StoreID,1,3)) as 'Location', CustomerID, SalesDate as 'Date', CAST(Sales as FLOAT) as Sales
FROM usasales
ORDER BY Sales DESC
-- Save the output in a CSV file as C:\Classfiles\Sales_by_Amount.csv
GO
SELECT UPPER(SubString(StoreID,1,3)) as 'Location', CustomerID, SalesDate as 'Date', Sales
FROM cansales
UNION
SELECT UPPER(SubString(StoreID,1,3)) as 'Location', CustomerID, SalesDate as 'Date', Sales
FROM mexsales
UNION
SELECT UPPER(SubString(StoreID,1,3)) as 'Location', CustomerID, SalesDate as 'Date', Sales
FROM usasales
ORDER BY CustomerID
GO
-- Save the output in a CSV file as C:\Classfiles\Sales_by_CustomerID.csv
-- Use three tables in the AdventureWorks2019 database to perform an INNER JOIN operation
-- You will get the phone number and phone number type for each person
USE AdventureWorks2019
GO
SELECT p.BusinessEntityID as ID, LastName, FirstName, ph.PhoneNumber
FROM Person.Person as p 
INNER JOIN Person.PersonPhone as ph
ON p.BusinessEntityID = ph.BusinessEntityID 
ORDER BY p.LASTNAME, p.FIRSTNAME
GO
SELECT p.BusinessEntityID as ID, LastName, FirstName, pt.[Name] as [PhoneType], ph.PhoneNumber
FROM Person.Person as p 
JOIN Person.PersonPhone as ph
ON p.BusinessEntityID = ph.BusinessEntityID 
JOIN Person.PhoneNumberType as pt
ON ph.PhoneNumberTypeID = pt.PhoneNumberTypeID
ORDER BY LASTNAME, FIRSTNAME
GO


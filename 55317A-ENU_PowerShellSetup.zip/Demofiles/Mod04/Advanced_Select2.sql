-- Use subqueries in SELECT, FROM & WHERE clauses
USE AdventureWorks2019
GO
-- This subquery expression is included in the SELECT statement to substitute for a column
-- It can replace an INNER JOIN operation
SELECT p.BusinessEntityID as ID, LastName, FirstName, 
(SELECT PhoneNumber FROM Person.PersonPhone as ph WHERE ph.BusinessEntityID = p.BusinessEntityID) as [Phone Number] 
FROM Person.Person as p 
ORDER BY LastName, FirstName
GO
-- This subquery expression can substitute for a filtered table
SELECT * 
FROM (SELECT PersonType,LastName,FirstName,EmailPromotion FROM Person.Person WHERE EmailPromotion = 1) as t
WHERE PersonType <> 'IN'
ORDER BY PersonType
GO
-- This subquery expression can filter data based on dynamic parameters 
-- Compare sales figures in USA to AVG and MAX sales in Canada
USE sales
GO
SELECT * FROM usasales
WHERE Sales >= (SELECT AVG(CAST(Sales as INT)) FROM cansales)
ORDER BY Sales DESC
GO
SELECT * FROM usasales
WHERE Sales >= (SELECT MAX(CAST(Sales as INT)) FROM cansales)
ORDER BY Sales DESC
GO
-- Review Sales in Canada for the customer that had the highest sales in Mexico
-- First, test the query to return the Customer with the highest sales in Mexico
SELECT CustomerID, SUM(CAST(Sales as INT)) as TotalSales FROM mexsales GROUP BY CustomerID Order BY SUM(CAST(Sales as INT)) DESC
GO
SELECT CustomerID, StoreID, SalesDate, CAST(Sales as INT) as Sales FROM cansales
WHERE CustomerID = (SELECT TOP 1 CustomerID FROM mexsales GROUP BY CustomerID Order BY SUM(CAST(Sales as INT)) DESC )
ORDER BY Sales DESC

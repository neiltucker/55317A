-- Use virtual and temporary tables in queries
-- Use a CTE to query data from all sales tables
USE sales
GO
WITH cte_sales ([Manager ID], [Store ID], [Sales Date], Sales) AS 
(SELECT * FROM cansales
UNION
SELECT * FROM mexsales
UNION
SELECT * FROM usasales)
SELECT * FROM cte_sales
ORDER BY [Sales Date] 
GO
-- Group sales by StoreID with the same CTE
WITH cte_sales AS 
(SELECT * FROM cansales
UNION
SELECT * FROM mexsales
UNION
SELECT * FROM usasales)
SELECT StoreID, SUM(CAST(Sales as INT)) as TotalSales FROM cte_sales
GROUP BY StoreID
ORDER BY TotalSales DESC
-- Use a temporary table to query data from all sales tables
USE sales
GO
WITH cte_sales ([Manager ID], [Store ID], [Sales Date], Sales) AS 
(SELECT * FROM cansales
UNION
SELECT * FROM mexsales
UNION
SELECT * FROM usasales)
SELECT * 
INTO #temp_sales1
FROM cte_sales
GO
-- Group sales by StoreID with this global temporary table
WITH cte_sales AS 
(SELECT * FROM cansales
UNION
SELECT * FROM mexsales
UNION
SELECT * FROM usasales)
SELECT StoreID, SUM(CAST(Sales as INT)) as TotalSales 
INTO ##temp_sales2
FROM cte_sales
GROUP BY StoreID
GO
-- Test the temporary tables
SELECT * FROM #temp_sales1
ORDER BY [Sales Date]
GO
SELECT * FROM ##temp_sales2
ORDER BY TotalSales DESC
GO
-- Verify the tables still exist in the tempdb database
SELECT [Name], Type_Desc, Create_Date FROM tempdb.sys.objects
WHERE [Name] LIKE '%temp_sales%'
GO
-- Create a new query window using SQL Server authentication (User: sa / Password: Pa$$w0rd).  
--Verify that you can only access the global temporary table using the queries below:
SELECT * FROM ##temp_sales2
GO
SELECT * FROM #temp_sales1
GO
SELECT [Name], Type_Desc, Create_Date FROM tempdb.sys.objects
WHERE [Name] LIKE '%temp_sales%'
GO
-- Change the credentials of this session to use SQL Server authentication (User: sa / Password: Pa$$w0rd).  
-- Verify that both tables are dropped.
SELECT [Name], Type_Desc, Create_Date FROM tempdb.sys.objects
WHERE [Name] LIKE '%temp_sales%'
GO
SELECT * FROM ##temp_sales2
GO
SELECT * FROM #temp_sales1
GO
-- If the tables are recreated, drop them using the commands below
DROP TABLE #temp_sales1
GO
DROP TABLE #temp_sales2
GO
-- Close all query sessions when finished.

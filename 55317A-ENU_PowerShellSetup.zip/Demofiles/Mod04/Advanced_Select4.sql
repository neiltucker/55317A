-- Use VIEWS to query data
-- Create and use a VIEW
SET STATISTICS IO ON
GO
USE sales
GO
CREATE VIEW vSales
AS
SELECT * FROM cansales
UNION
SELECT * FROM mexsales
UNION
SELECT * FROM usasales
GO
SELECT * FROM vSales
GO
-- Create a second VIEW to group sales by StoreID
CREATE VIEW vSalesByStoreID
AS
WITH cte_sales AS 
(SELECT * FROM cansales
UNION
SELECT * FROM mexsales
UNION
SELECT * FROM usasales)
SELECT StoreID, SUM(CAST(Sales as INT)) as TotalSales FROM cte_sales
GROUP BY StoreID
GO
SELECT * FROM vSalesByStoreID
ORDER BY TotalSales DESC
GO
-- Run a complex query.  Make a note of how long it runs.
USE AdventureWorks2019
GO
SELECT 
Production.TransactionHistory.TransactionID, Sales.SalesOrderDetail.SalesOrderDetailID, Production.Product.[Name] as ProductName, Production.Product.ProductNumber, Sales.SpecialOffer.SpecialOfferID, Sales.SpecialOffer.[Description]
FROM Sales.SalesOrderDetail 
INNER JOIN Production.Product 
ON Sales.SalesOrderDetail.ProductID = Production.Product.ProductID 
INNER JOIN Sales.SpecialOffer 
ON Sales.SalesOrderDetail.SpecialOfferID = Sales.SpecialOffer.SpecialOfferID 
INNER JOIN Production.TransactionHistory 
ON Production.Product.ProductID = Production.TransactionHistory.ProductID 
WHERE ProductNumber LIKE 'BK%'
GO
-- Create a VIEW on the query and then index it
CREATE VIEW vBikeTransactions
WITH SCHEMABINDING  -- This option is required to create an index on the view.  It prevents accidental deletion of underlying tables.
AS
SELECT 
Production.TransactionHistory.TransactionID, Sales.SalesOrderDetail.SalesOrderDetailID, Production.Product.[Name] as ProductName, Production.Product.ProductNumber, Sales.SpecialOffer.SpecialOfferID, Sales.SpecialOffer.[Description]
FROM Sales.SalesOrderDetail 
INNER JOIN Production.Product 
ON Sales.SalesOrderDetail.ProductID = Production.Product.ProductID 
INNER JOIN Sales.SpecialOffer 
ON Sales.SalesOrderDetail.SpecialOfferID = Sales.SpecialOffer.SpecialOfferID 
INNER JOIN Production.TransactionHistory 
ON Production.Product.ProductID = Production.TransactionHistory.ProductID 
WHERE ProductNumber LIKE 'BK%'
GO
-- Create a UNIQUE CLUSTERED INDEX on the view.  This may take a few minutes.  Run the view to verify that it executes faster than the query.
CREATE UNIQUE CLUSTERED INDEX CI_vBikeTransactions
   ON dbo.vBikeTransactions (TransactionID, SalesOrderDetailID, ProductNumber)
GO
SELECT * FROM vBikeTransactions
GO
SELECT TransactionID, SalesOrderDetailID, ProductNumber
FROM vBikeTransactions
GO
-- Restart the SQL Server service when this exercise is complete.
-- Grant sqllogin1 and sqllogin2 access to the database
USE AdventureWorks2019
GO
CREATE USER sqllogin1 FOR LOGIN sqllogin1
GO
CREATE USER sqllogin2 FOR LOGIN sqllogin2
GO
-- Grant permissions to a view and test it
GRANT SELECT ON dbo.vCustomerPhone TO sqllogin1
GO
-- Test sqllogin1 and sqllogin2 permissions to the view
-- Only sqllogin1 will have access to the view
EXECUTE AS LOGIN = 'sqllogin1'
SELECT * FROM vCustomerPhone
GO
REVERT
GO
EXECUTE AS LOGIN = 'sqllogin2'
SELECT * FROM vCustomerPhone
GO
REVERT
GO

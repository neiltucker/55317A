/* Query Customer Table */

SELECT CustomerID, StoreID, AccountNumber, ModifiedDate AS [Date Modified]
FROM AdventureWorks2019.Sales.Customer
Where StoreID > 1000
Order By AccountNumber ASC


SELECT 
Person.FirstName, 
Person.LastName, 
Employees.NationalIDNumber, 
Employees.JobTitle, 
Employees.BirthDate
FROM AdventureWorks2019.HumanResources.Employee AS Employees 
INNER JOIN AdventureWorks2019.Person.Person AS Person 
ON Employees.BusinessEntityID = Person.BusinessEntityID


/* Create a temporary table to test T-SQL clauses */

-- 1. Minimum and maximum values using GREATEST and LEAST
-- DROP TABLE #Exams
SELECT CAST(Rand()*100 as int) as [Student1], CAST(Rand()*100 as int) as [Student2], CAST(Rand()*100 as int) as [Student3], CAST(Rand()*100 as int) as [Student4] 
INTO #Exams
UNION ALL
SELECT CAST(Rand()*100 as int), CAST(Rand()*100 as int), CAST(Rand()*100 as int), CAST(Rand()*100 as int)
UNION ALL
SELECT CAST(Rand()*100 as int), CAST(Rand()*100 as int), CAST(Rand()*100 as int), CAST(Rand()*100 as int)
UNION ALL
SELECT CAST(Rand()*100 as int), CAST(Rand()*100 as int), CAST(Rand()*100 as int), CAST(Rand()*100 as int)
UNION ALL
SELECT CAST(Rand()*100 as int), CAST(Rand()*100 as int), CAST(Rand()*100 as int), CAST(Rand()*100 as int)
GO
SELECT * FROM #Exams
GO
SELECT MAX(Student1) FROM #Exams
GO
SELECT MIN(Student1) FROM #Exams
GO
SELECT GREATEST(Student1,Student2,Student3,Student4) FROM #Exams
GO
SELECT LEAST(Student1,Student2,Student3,Student4) FROM #Exams
GO

-- 2. Generate a series of numbers
SELECT value FROM GENERATE_SERIES(1,5)
GO
SELECT value FROM GENERATE_SERIES(1.0,5.0,0.5)
GO
SELECT value FROM GENERATE_SERIES(0,50,5)
GO

-- 3. Spliting a string variable
SELECT * FROM STRING_SPLIT('68|85|46|75|93', '|')
GO
SELECT * FROM STRING_SPLIT('This is a test.', N' ',1)
WHERE ordinal = 4
GO
SELECT * FROM STRING_SPLIT('John,William,Victor,Elizabeth,Janelle,Andrea', N',',1)
WHERE ordinal = 3
GO

-- 4. Truncate date values
DECLARE @date datetime2 = '2022-12-14 12:15:50.0123456'
SELECT 'Year', DATETRUNC(yyyy, @date)
SELECT 'Month', DATETRUNC(month, @date)
SELECT 'Week', DATETRUNC(week, @date)
SELECT 'Day', DATETRUNC(day, @date) 
SELECT 'Hour', DATETRUNC(hour, @date) 

-- Query customer emails and phone numbers
USE AdventureWorks2019
GO
SELECT 
Person.Person.LastName, 
Person.Person.FirstName, 
Person.EmailAddress.EmailAddress, 
Person.PersonPhone.PhoneNumber
FROM Person.Person 
INNER JOIN Person.EmailAddress 
ON Person.Person.BusinessEntityID = Person.EmailAddress.BusinessEntityID 
INNER JOIN Person.PersonPhone 
ON Person.Person.BusinessEntityID = Person.PersonPhone.BusinessEntityID
ORDER BY LastName, FirstName
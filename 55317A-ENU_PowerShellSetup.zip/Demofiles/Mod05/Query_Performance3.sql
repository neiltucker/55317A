-- Use the Database Engine Tuning Advisor (DTA) and Memory-Optimized Tables to improve query performance.
-- Note: The performance of these measures depend on the number of rows processed, query and index structures.
USE master
GO
-- Create database and table
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'sales')
BEGIN
    DROP DATABASE sales
END
CREATE DATABASE sales
GO
USE sales
GO
CREATE TABLE [dbo].[sales](
    [ID] INT IDENTITY(1,1) PRIMARY KEY CLUSTERED,
	[CustomerID] [varchar](100) NULL,
	[StoreID] [varchar](100) NULL,
	[SalesDate] [varchar](100) NULL,
	[Sales] [varchar](100) NULL
) 
GO
-- Import sales figures for Canada, Mexico and USA
USE sales
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_can.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_mex.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_usa.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
-- BEFORE PROCEEDING, RIGHT-CLICK THE QUERY WINDOW AND SELECT "Trace query in SQL Server Profiler".  If necessary, connect to the local SQL Server instance.
-- The SQL Server Profile window will open.  Minimize it and continue with the next section.
-- Query the sales table many times (e.g., "GO 100") using different queries to simulate a workload.  This workload will be used for the DTA.
-- You can re-open the SQL Server Profiler window to watch the progress of the workload.  Do not continue until all the queries execute successfully.
SELECT * FROM sales
GO 100
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY CustomerID
GO 150
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY StoreID
GO 200
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY Sales DESC
GO 250
SELECT StoreID FROM sales
WHERE Sales > 1000
GO 300
SELECT Sales FROM sales
WHERE StoreID LIKE 'usa%'
GO 350
SELECT StoreID FROM sales
GO 400
SELECT Sales FROM sales
GO 500
-- Stop the trace in SQL Server profiler. Follow the following steps carefully to configure SQL Server Profiler & DTA 
-- From the menu, click File > Save As > Trace File.  Save the file as C:\Classfiles\save.trc
-- From the menu, click Tools > Database Engine Tuning Advisor.  Connect to the local SQL Server instance
-- In the DTA, in the General tab, browse for and select the workload file: C:\Classfiles\save.trc
-- Change the "Database for workload to analyze" to sales
-- Under "Select databases and tables to tune:" select sales
-- Click the "Tuning Options" tab.  Click the "Advanced Options" button.
-- In the "Advanced Tuning Options" window, set the "Define max. space for recommendations(MB)" to 1000.  Click OK.
-- Without changing any settings, review the options in the "Tuning Options" tab.
-- On the toolbar, click the "Start Analysis" button.
-- Make a note of the "Definition" of the new indexes being recommended.
-- From the menu, click Actions > Apply Recommendations
-- In the "Apply Recommendations" window, select "Apply now" then click OK > Close.
-- List the new indexes created from the DTA recommendations for the sales table
USE sales
GO
EXECUTE sys.sp_helpindex @objname = 'sales'
GO
-- If time permits, run the queries again and compare the time it takes to the previous configuration without indexes.
SELECT * FROM sales
GO 100
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY CustomerID
GO 150
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY StoreID
GO 200
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY Sales DESC
GO 250
SELECT StoreID FROM sales
WHERE Sales > 1000
GO 300
SELECT Sales FROM sales
WHERE StoreID LIKE 'usa%'
GO 350
SELECT StoreID FROM sales
GO 400
SELECT Sales FROM sales
GO 500
--  Connect to master and close all existing connections to sales
USE master
GO
-- Drop and recreate the sales database with a memory optimized filegroup and a container.
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'sales')
BEGIN
    DROP DATABASE sales
END
CREATE DATABASE sales
GO
ALTER DATABASE sales ADD FILEGROUP memory1 CONTAINS MEMORY_OPTIMIZED_DATA 
GO
ALTER DATABASE sales 
ADD FILE (name='sales_memory1', filename='c:\temp\sales_memory1')
TO FILEGROUP memory1
GO
-- Create a Memory-Optimized table for sales
USE sales
GO
CREATE TABLE [dbo].[sales](
    [ID] INT IDENTITY(1,1) PRIMARY KEY NONCLUSTERED,
	[CustomerID] [varchar](100) NULL,
	[StoreID] [varchar](100) NULL,
	[SalesDate] [varchar](100) NULL,
	[Sales] [varchar](100) NULL
) WITH (MEMORY_OPTIMIZED=ON)
GO
-- Import sales figures for Canada, Mexico and USA
USE sales
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_can.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_mex.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_usa.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
-- Create indexes
ALTER TABLE sales  
ADD CONSTRAINT ni_customerid  
UNIQUE NONCLUSTERED (CustomerID, ID)  
GO
ALTER TABLE sales  
ADD CONSTRAINT ni_storeid  
UNIQUE NONCLUSTERED (StoreID, ID)  
GO
ALTER TABLE sales  
ADD CONSTRAINT ni_sales  
UNIQUE NONCLUSTERED (Sales, ID)  
GO
--  Execute the same queries as before.  
-- Using the same procedure as before, create a WORKLOAD and run it using the DTA to get and apply index recommendations.
SELECT * FROM sales
GO 100
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY CustomerID
GO 150
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY StoreID
GO 200
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY Sales DESC
GO 250
SELECT StoreID FROM sales
WHERE Sales > 1000
GO 300
SELECT Sales FROM sales
WHERE StoreID LIKE 'usa%'
GO 350
SELECT StoreID FROM sales
GO 400
SELECT Sales FROM sales
GO 500
-- Run the above queries again after the index recommendations are applied.  Which solution would you use for optimizing queries and why?

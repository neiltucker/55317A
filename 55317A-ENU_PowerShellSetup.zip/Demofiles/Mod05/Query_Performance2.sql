-- Create Indexes on tables and run queries to see how they are structured.
-- On the menu bar, Query > Include Actual Execution Plan.  This will allow you to review the execution plan of each query.
USE master
GO
-- Create database and table
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'sales')
BEGIN
    DROP DATABASE sales
END
CREATE DATABASE sales
GO
USE sales
GO
CREATE TABLE [dbo].[sales](
	[CustomerID] [varchar](100) NULL,
	[StoreID] [varchar](100) NULL,
	[SalesDate] [varchar](100) NULL,
	[Sales] [varchar](100) NULL
)
GO
CREATE CLUSTERED INDEX CI_CustomerID   
ON dbo.sales (CustomerID);   
GO  
-- Import sales figures for Canada, Mexico and USA into a single sales table
USE sales
GO
INSERT INTO dbo.sales
SELECT *
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_can.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
INSERT INTO dbo.sales
SELECT *
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_mex.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
INSERT INTO dbo.sales
SELECT *
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_usa.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
-- Query the sales table.  The execution plan will confirm that all queries use the clustered index since its the only one available.
SELECT * FROM sales
GO
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY CustomerID
GO
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY StoreID
GO
SELECT CustomerID, StoreID, Sales FROM sales
ORDER BY Sales DESC
GO
SELECT StoreID FROM sales
WHERE Sales > 1000
GO
SELECT Sales FROM sales
WHERE StoreID LIKE 'usa%'
GO
SELECT StoreID FROM sales
GO
SELECT Sales FROM sales
GO
-- Create Non-Clustered Index
CREATE NONCLUSTERED INDEX NI_StoreID   
ON dbo.sales (StoreID) 
GO
CREATE NONCLUSTERED INDEX NI_Sales
ON dbo.sales (Sales) 
GO
CREATE NONCLUSTERED INDEX NI_StoreID_Sales
ON dbo.sales (StoreID, Sales) 
GO
-- Run the same queries again and verify which indexes are used this time.  The execution plan will confirm that all queries use the clustered index since its the only one available.
SELECT * FROM sales
GO
SELECT StoreID, Sales FROM sales
ORDER BY CustomerID
GO
SELECT StoreID, Sales FROM sales
ORDER BY StoreID
GO
SELECT StoreID, Sales FROM sales
ORDER BY Sales DESC
GO
SELECT StoreID FROM sales
WHERE Sales > 1000
GO
SELECT Sales FROM sales
WHERE StoreID LIKE 'usa%'
GO
SELECT StoreID FROM sales
GO
SELECT Sales FROM sales
GO


-- Use execution plans to analyze a query.  
-- From the menu, click Tools > Include Actual Execution Plan.  
-- Run each query and view the associated "Execution plan" tab.
-- Note the number of steps and the resources used in each step.
USE [AdventureWorks2019]
GO
SELECT * FROM Sales.SalesPerson
GO
SELECT        
Sales.SalesPerson.BusinessEntityID, Sales.Store.SalesPersonID, Sales.Store.Name, Sales.SalesPerson.SalesYTD
FROM Sales.SalesPerson
INNER JOIN Sales.Store 
ON Sales.SalesPerson.BusinessEntityID = Sales.Store.SalesPersonID 
GO
SELECT 
sp.BusinessEntityID, ss.SalesPersonID, ss.[Name], sp.SalesYTD, sc.CustomerID
FROM Sales.Customer AS sc
INNER JOIN Sales.SalesPerson AS sp
INNER JOIN Sales.Store AS ss
ON sp.BusinessEntityID = ss.SalesPersonID 
ON sc.StoreID = ss.BusinessEntityID AND sc.StoreID = ss.BusinessEntityID
GO


-- Create and use functions
USE Sales
GO
DROP FUNCTION IF EXISTS ufnCustomerSales
GO
CREATE FUNCTION ufnCustomerSales (@CustomerID VARCHAR(10) = NULL)
RETURNS TABLE
AS
RETURN (
SELECT 
CustomerID, SUM(CAST(Sales as INT)) as [Total Sales]
FROM Sales
WHERE CustomerID LIKE @CustomerID
GROUP BY CustomerID
-- ORDER BY clause is best left out of user-defined functions
)
GO
DROP FUNCTION IF EXISTS dbo.ufnStoreSales
GO
CREATE FUNCTION dbo.ufnStoreSales()
RETURNS TABLE
AS
RETURN (SELECT 
StoreID, SUM(CAST(Sales as INT)) as [Total Sales]
FROM Sales
GROUP BY StoreID)
GO
DROP FUNCTION IF EXISTS dbo.ufnSquare
GO
CREATE FUNCTION dbo.ufnSquare (@number INT)
RETURNS INT
AS
BEGIN
    RETURN (@number * @number);
END
GO
-- Grant permissions to procedures
-- First grant access to database
-- SELECT permissions are needed for Table-valued functions.  
-- EXECUTE permissions are needed for scalar functions.
USE sales
GO
DROP USER IF EXISTS sqllogin1
GO
CREATE USER sqllogin1 FOR LOGIN sqllogin1
GO
GRANT SELECT ON SCHEMA::dbo TO sqllogin1
GO
DROP USER IF EXISTS sqllogin2
GO
CREATE USER sqllogin2 FOR LOGIN sqllogin2
GO
GRANT EXECUTE ON SCHEMA::dbo TO sqllogin2
GO
-- Execute functions
-- Create a new Query Editor window and login with SQL Authentication as sqllogin1 with a password of Pa$$w0rd
-- Copy the code in this section to the new window and execute it as sqllogin1
-- Create a new Query Editor window and login with SQL Authentication as sqllogin2 with a password of Pa$$w0rd
-- Copy the code in this section to the new window and execute it as sqllogin2
USE sales
GO
SELECT * FROM ufnCustomerSales('%')
ORDER BY CustomerID  -- To sort a table-valued function, it is best to use the ORDER BY clause in the query instead of the definition.
GO
SELECT * FROM dbo.ufnCustomerSales('BG96')
GO
SELECT * FROM dbo.ufnStoreSales()
ORDER BY StoreID
GO
SELECT dbo.ufnSquare(15) as 'Square'
GO
SELECT dbo.ufnSquare() as 'Square'
GO
-- Identify which functions work for which user and why

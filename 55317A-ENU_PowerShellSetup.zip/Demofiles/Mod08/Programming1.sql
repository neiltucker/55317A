-- Work with commonly used built-in stored procedures and functions.
-- If multiple procedures are executed in the same batch, precede their names with the EXEC or EXECUTE keyword.
-- Create a database and tables for use in the exercise:
DROP DATABASE IF EXISTS Schools
GO
CREATE DATABASE Schools
GO
USE Schools
GO
DROP TABLE IF EXISTS Teachers1
GO
CREATE TABLE Teachers1 (
RecordID INT IDENTITY(1,1) PRIMARY KEY,
Teachers XML NOT NULL
)
GO
DECLARE @xml NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.xml', SINGLE_CLOB) AS XMLData)
INSERT INTO Teachers1 (Teachers)
VALUES (@xml)
GO
DECLARE @json NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.json', SINGLE_CLOB) AS JSONData)
SELECT *
INTO Teachers2
FROM OPENJSON(@json)
WITH (
  TeacherID INT,
  RoomID INT,
  FirstName NVARCHAR(50),
  LastName NVARCHAR(50)
)
GO
-- Get information about databases.
sp_helpdb
GO
sp_helpdb Schools
GO
-- Get information about database objects
sp_help 'Teachers1'
GO
-- Use dynamic values in a query
DECLARE @sql NVARCHAR(MAX)
DECLARE @param1 INT = 107
SET @sql = N'SELECT * FROM Teachers2 WHERE TeacherID = @p1'
EXEC sp_executesql @sql, N'@p1 INT', @param1
GO
-- Information about the current users and connections to this SQL Server instance
-- TO get the current session ID: SELECT @@SPID AS 'Session ID'
sp_who 
GO
sp_who 'Active'
GO
sp_who @@SPID
GO
--  Display the current locks on the instance.
sp_lock 
GO
sp_lock @@SPID
GO
-- Rename an object
SELECT * FROM Teachers2
GO
sp_rename Teachers2, Teachers3
GO
SELECT * FROM Teachers3
GO
-- Find out how much space is used by a database or table
sp_spaceused
GO
sp_spaceused 'Teachers3'
GO
SELECT HOST_NAME(), * FROM TEACHERS3
GO
-- Use commonly used functions
-- Create the sales database to be used for this exercise
USE master
GO
DROP DATABASE IF EXISTS sales
GO
CREATE DATABASE sales
GO
USE sales
GO
CREATE TABLE [dbo].[sales](
    [ID] INT IDENTITY(1,1) PRIMARY KEY CLUSTERED,
	[CustomerID] [varchar](100) NULL,
	[StoreID] [varchar](100) NULL,
	[SalesDate] [varchar](100) NULL,
	[Sales] [varchar](100) NULL
) 
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_can.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_mex.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_usa.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t
GO
-- Use system functions
SELECT @@SPID as 'Session ID', USER_NAME() as 'Current User', SUSER_NAME() as 'Current Login', DB_Name() as 'Current Database'
GO
SELECT * FROM Sales
WHERE StoreID = 'can96'
IF @@ROWCOUNT < 10 
  PRINT 'This customer had less than 10 sales'  
ELSE
  PRINT 'This customer had 10 or more sales'
GO
-- Use the messages tab to verify the displayed message.
GO 
-- Use string functions
SELECT CustomerID, StoreID, CONCAT(CustomerID,'-',StoreID) as InvoiceID
FROM Sales
GO
SELECT CustomerID, StoreID, CONCAT(SUBSTRING(CustomerID,1,2),'-',Substring(StoreID,1,3)) as LocationID
FROM Sales
GO
SELECT CustomerID, StoreID, UPPER(CONCAT(SUBSTRING(CustomerID,1,2),'-',Substring(StoreID,1,3))) as LocationID
FROM Sales
GO
-- Use aggregate functions
SELECT COUNT(*) as 'Total Rows' FROM Sales
GO
SELECT CustomerID, SUM(CAST(Sales as INT)) as 'Total Sales' FROM sales
GROUP BY CustomerID
GO
-- Use Date Functions
SELECT 
FORMAT(CURRENT_TIMESTAMP,'yyyy-MM-dd') AS 'Current Date',
FORMAT(CAST(SalesDate as DATE), 'yyyy-MM-dd') AS 'Sales Date',
FORMAT(CAST(SalesDate as DATE), 'yyyy') AS 'Sales Year',
FORMAT(CAST(SalesDate as DATE), 'MM') AS 'Sales Month',
FORMAT(CAST(SalesDate as DATE), 'dd') AS 'Sales Day'
FROM Sales
GO
SELECT 
CustomerID, StoreID, Sales, CAST(SalesDate as DATE) as 'Sales Date', CAST(SalesDate as DATETIME) as 'Sales DateTime'
FROM Sales
GO
SELECT 
CustomerID, StoreID, SalesDate, DATEDIFF(DAY, SalesDate, GetDate()) AS 'Days Since Sale'
FROM Sales
ORDER BY SalesDate DESC
GO
-- Use Logical Functions
SELECT 
CustomerID, StoreID, SalesDate,
CHOOSE(MONTH(SalesDate),'January','February','March','April','May','June', 'July','August','September','October','November','December') as [Month of Sale]
FROM Sales
ORDER BY CustomerID
GO
SELECT
CustomerID, StoreID, SalesDate,
IIF(SUBSTRING(StoreID,1,3) = 'usa', 'YES','NO') as 'Sale in USA'
FROM Sales
ORDER BY CustomerID
GO

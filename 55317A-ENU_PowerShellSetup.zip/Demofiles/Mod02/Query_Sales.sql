SELECT 
      [BusinessEntityID] AS ID
      ,[FirstName]
      ,[LastName]
      ,[JobTitle]
      ,[PhoneNumber]
      ,[EmailAddress]
      ,[SalesYTD]
  FROM [AdventureWorks2019].[Sales].[vSalesPerson]
-- Connect to database
USE AdventureWorks2019
GO
-- Manage table columns to control the format of the result set
SELECT * FROM Sales.SalesYTD
GO
SELECT ID as [Business ID], SalesYTD as 'YTD Sales'
FROM Sales.SalesYTD
GO
SELECT Round(SalesYTD,2), ID FROM Sales.SalesYTD
GO
SELECT * FROM Sales.Orders
GO
SELECT CustomerID, OrderID, Quantity, Price, Freight, ShippedDate
FROM Sales.Orders
GO
SELECT OrderID, Quantity, Price
FROM Sales.Orders
GO
SELECT OrderID as [Order ID], CustomerID as [Customer ID], Price, Quantity, Round(CAST(Freight as FLOAT)/2,2) as [Discounted Freight] 
FROM Sales.Orders
GO
SELECT OrderID, CustomerID, ROUND((CAST(Quantity as INT) * CAST(Price as FLOAT) + CAST(Freight as FLOAT)), 2) AS TotalSales
FROM Sales.Orders
GO
-- Query Table and Column information
SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Orders'
GO
EXECUTE SP_HELP 'Sales.Orders'
GO
-- If Time permits, use Azure Data Studio (ADS) to convert this .sql file to .ipynb and run the queries in a notebook
-- This can be done by opening the query in an ADS Query Editor window and using the "Export as Notebook" option



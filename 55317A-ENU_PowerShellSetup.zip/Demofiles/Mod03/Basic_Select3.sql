-- Connect to database
USE AdventureWorks2019
GO
-- Filter data by using DISTINCT and WHERE
SELECT * FROM Sales.Orders
GO
SELECT DISTINCT Freight FROM Sales.Orders
GO
SELECT DISTINCT ManagerID FROM Sales.Orders
GO
SELECT ID, SalesYTD FROM Sales.SalesYTD
GO
SELECT ID, SalesYTD FROM Sales.SalesYTD
WHERE SalesYTD > 1000000
GO
SELECT ID, SalesYTD FROM Sales.SalesYTD
WHERE ID > 280
GO
SELECT ID, SalesYTD FROM Sales.SalesYTD
WHERE ID > 280 OR SalesYTD > 1000000
GO
SELECT ID, SalesYTD FROM Sales.SalesYTD
WHERE ID > 280 AND SalesYTD > 1000000
GO
SELECT ID, SalesYTD FROM Sales.SalesYTD
WHERE ID BETWEEN 285 AND 290
GO
SELECT ID, SalesYTD FROM Sales.SalesYTD
WHERE ID IN (286,287,288)
GO
SELECT ID, SalesYTD FROM Sales.SalesYTD
WHERE ID LIKE '28%'
GO
-- Sort data with the ORDER BY clause
-- Note: ORDER BY cannot be used by columns with data types: text, xml, image, geography or geometry
SELECT 
CustomerID, OrderID, ShippedDate, Quantity, Price, Freight, CAST(Quantity as INT) * CAST(Price as FLOAT) + CAST(Freight as FLOAT) AS TotalSales
FROM Sales.Orders
WHERE Quantity > 50
ORDER BY 3          -- 3 is the column number for ShippedDate
GO
SELECT TOP 100
CustomerID, CAST(OrderID as INT) AS 'Order ID', ShippedDate, Quantity, Price, Freight, CAST(Quantity as INT) * CAST(Price as FLOAT) + CAST(Freight as FLOAT) AS TotalSales
FROM Sales.Orders
WHERE Quantity > 50
ORDER BY CustomerID, 'Order ID'  -- Convert OrderID to INT to ensure sorting is done properly
GO
SELECT TOP 100
CustomerID, ShippedDate, OrderID, Quantity, Price, Freight, CAST(Quantity as INT) * CAST(Price as FLOAT) + CAST(Freight as FLOAT) AS TotalSales
FROM Sales.Orders
WHERE Quantity > 50
ORDER BY CustomerID, ShippedDate, TotalSales DESC       -- ORDER BY will also work with calculated fields like TotalSales
GO
SELECT TOP 100
CustomerID, OrderID, ShippedDate, Quantity, Price, CAST(Freight as FLOAT) AS [Shipping Cost], ROUND((CAST(Quantity as INT) * CAST(Price as FLOAT) + CAST(Freight as FLOAT)), 2) AS TotalSales
FROM Sales.Orders
WHERE Price > 50.00         -- If 50 was used, the system would try to convert price values to INT
ORDER BY Price ASC, 'Shipping Cost'               -- Ascending (ASC) is the default sort order, but it can also be specified
GO
SELECT TOP 100 CustomerID, OrderID, ShippedDate FROM Sales.Orders
ORDER BY Price      -- The column name 'Price' does not need to be specified in the SELECT statement
GO
SELECT DISTINCT SCHEMA_NAME(schema_id) AS 'Schema Name' FROM sys.objects 
ORDER BY 'Schema Name' 
GO
-- Group data using the GROUP BY clause
-- First, create a new table named Sales.Orders2
SELECT 
CustomerID, OrderID, ShippedDate, Quantity, Price, Freight, ROUND(CAST(Quantity as INT) * CAST(Price as FLOAT) + CAST(Freight as FLOAT),0) AS TotalSales
INTO Sales.Orders2
FROM Sales.Orders
GO
SELECT CustomerID, TotalSales FROM Sales.Orders2 
GO
SELECT CustomerID, SUM(TotalSales) AS Sales FROM Sales.Orders2 
GROUP BY CustomerID
GO
SELECT CustomerID, SUM(TotalSales) AS Sales FROM Sales.Orders2 
GROUP BY CustomerID
HAVING SUM(TotalSales) > 250000
ORDER BY Sales DESC 
GO
-- If Time permits, use Azure Data Studio (ADS) to convert this .sql file to .ipynb and run the queries in a notebook
-- This can be done by opening the query in an ADS Query Editor window and using the "Export as Notebook" option



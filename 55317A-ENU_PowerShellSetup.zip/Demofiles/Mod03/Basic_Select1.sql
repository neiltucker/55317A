-- Connect to database
USE AdventureWorks2019
GO
-- Run queries on the vSalesPerson View using different syntax
-- Note: To browse new items or resources in SSMS or ADS, you may need to refresh the database first by right-clicking it and selecting "Refresh"
SELECT * FROM Sales.vSalesPerson
GO
SELECT LastName, FirstName, BusinessEntityID as ID
FROM AdventureWorks2019.Sales.vSalesPerson
GO
SELECT BusinessEntityID AS ID, FORMAT(SalesYTD, 'C2') AS SalesYTD
FROM [55317MIASQL].AdventureWorks2019.Sales.vSalesPerson
GO
-- Create a new table using the INTO statement
SELECT BusinessEntityID as ID, SalesYTD 
INTO Sales.SalesYTD
FROM Sales.vSalesPerson
GO
SELECT * 
INTO Sales.Orders
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_order_data.csv',
     FORMATFILE='C:\classfiles\tools\orders.fmt', FIRSTROW=2) AS Orders
GO
-- Format output as XML or JSON
SELECT LastName, FirstName, BusinessEntityID as ID
FROM AdventureWorks2019.Sales.vSalesPerson
FOR XML AUTO
GO
SELECT LastName, FirstName, BusinessEntityID as ID
FROM AdventureWorks2019.Sales.vSalesPerson
FOR JSON AUTO
GO
-- Verify the new tables created in this exercise are available before proceeding with the next task


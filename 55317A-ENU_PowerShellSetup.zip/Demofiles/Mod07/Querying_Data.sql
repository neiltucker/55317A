-- Query JSON and XML data
USE AdventureWorks2019
GO
-- Query JSON from a remote source
-- Keep JSON format.  View the results using both, "Results to Text (Ctrl+T)" & "Results to Grid (Ctrl+D)" options on the toolbar.
DECLARE @json NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.json', SINGLE_CLOB) AS JSONData)
SELECT @json
GO
-- Use relational format to view data.  Click the "Results to Grid (Ctrl+D)" icon on the toolbar first.
DECLARE @json NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.json', SINGLE_CLOB) AS JSONData)
SELECT *
FROM OPENJSON(@json)
WITH (
TeacherID INT,
RoomID INT,
FirstName NVARCHAR(50),
LastName NVARCHAR(50)
)
GO
-- Query JSON records in a table
SELECT * FROM Teachers3
GO
SELECT RecordID, JSON_QUERY(Teachers,'$') as Teachers FROM Teachers3
GO
SELECT RecordID, JSON_QUERY(Teachers,'$[0]') as Teachers FROM Teachers3
GO
SELECT T.RecordID, J.TeacherID, J.RoomID, J.FirstName, J.LastName
FROM Teachers3 as T
CROSS APPLY OPENJSON(T.Teachers)
WITH (
TeacherID INT,
RoomID INT,
FirstName NVARCHAR(50),
LastName NVARCHAR(50)
) as J;
GO
-- Query XML data
DECLARE @xml NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.xml', SINGLE_CLOB) AS XMLData)
SELECT @xml
GO
DECLARE @xml NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'c:\classfiles\tools\teachers.xml', SINGLE_BLOB) AS x)
SELECT 
T.value('TeacherID[1]', 'INT') as TeacherID,
T.value('RoomID[1]', 'INT') as RoomID,
T.value('FirstName[1]', 'NVARCHAR(50)') as FirstName,
T.value('LastName[1]', 'NVARCHAR(50)') as LastName
FROM (SELECT CONVERT(XML, @xml) AS xmlData) AS temp
CROSS APPLY xmlData.nodes('/data/row') as x(T)
GO
SELECT * FROM Teachers4
GO
SELECT 
RecordID,
T.value('TeacherID[1]', 'INT') as TeacherID,
T.value('RoomID[1]', 'INT') as RoomID,
T.value('FirstName[1]', 'NVARCHAR(50)') as FirstName,
T.value('LastName[1]', 'NVARCHAR(50)') as LastName
FROM teachers4
CROSS APPLY teachers.nodes('/data/row') AS x(T)
GO

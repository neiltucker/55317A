-- Converting relational data to JSON and XML formats
USE AdventureWorks2019
GO
-- Convert relational data to JSON
SELECT * FROM Teachers1
FOR JSON AUTO
-- Save the result set as C:\Classfiles\teachers1.json and open the file to verify the format of the data.
GO
-- Convert CSV file to JSON
SELECT *
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_usa.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t
FOR JSON AUTO
-- Save the result set as C:\Classfiles\raw_sales_data_usa.json and open the file to verify the format of the data.
GO
-- Convert XML file to JSON
DECLARE @xml NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'c:\classfiles\tools\teachers.xml', SINGLE_BLOB) AS x)
SELECT 
T.value('TeacherID[1]', 'INT') as TeacherID,
T.value('RoomID[1]', 'INT') as RoomID,
T.value('FirstName[1]', 'NVARCHAR(50)') as FirstName,
T.value('LastName[1]', 'NVARCHAR(50)') as LastName
FROM (SELECT CONVERT(XML, @xml) AS xmlData) AS temp
CROSS APPLY xmlData.nodes('/data/row') as x(T)
FOR JSON AUTO
-- Save the result set as C:\Classfiles\teachers.json and open the file to verify the format of the data.
GO
-- Convert relational data to XML
SELECT * FROM Teachers1
FOR XML RAW
SELECT * FROM Teachers1
FOR XML AUTO
-- Click the result sets of both queries and compare them to verify how the rows are labeled differently.
-- Save the result set of the second query as C:\Classfiles\teachers1.xml.
GO
-- Convert CSV file to XML
SELECT *
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_usa.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t
FOR XML AUTO
-- Save the result set as C:\Classfiles\raw_sales_data_usa.xml and open the file to verify the format of the data.
GO
-- Convert JSON column to XML
SELECT T.RecordID, J.TeacherID, J.RoomID, J.FirstName, J.LastName
FROM Teachers3 as T
CROSS APPLY OPENJSON(T.Teachers)
WITH (
TeacherID INT,
RoomID INT,
FirstName NVARCHAR(50),
LastName NVARCHAR(50)
) as J
FOR XML AUTO
GO



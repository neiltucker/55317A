-- Store JSON and XML files in SQL Server Tables
USE AdventureWorks2019
GO
-- Store JSON in a relational format (rows and columns)
-- Use an existing table
DROP TABLE IF EXISTS Teachers1
GO
CREATE TABLE Teachers1 (
TeacherID INT,
RoomID INT,
FirstName NVARCHAR(50),
LastName NVARCHAR(50)
)
GO
DECLARE @json NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.json', SINGLE_CLOB) AS JSONData)
INSERT INTO Teachers1
SELECT *
FROM OPENJSON(@json)
WITH (
TeacherID INT,
RoomID INT,
FirstName NVARCHAR(50),
LastName NVARCHAR(50)
)
GO
SELECT * FROM Teachers1
GO
-- Create a table during INSERT
DECLARE @json NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.json', SINGLE_CLOB) AS JSONData)
SELECT *
INTO Teachers2
FROM OPENJSON(@json)
WITH (
  TeacherID INT,
  RoomID INT,
  FirstName NVARCHAR(50),
  LastName NVARCHAR(50)
)
GO
SELECT * FROM Teachers2
GO
-- Store in a JSON format
-- Create Table
DROP TABLE IF EXISTS Teachers3
GO
CREATE TABLE Teachers3 (
RecordID INT PRIMARY KEY IDENTITY,
Teachers NVARCHAR(MAX) NOT NULL
)
GO
ALTER TABLE Teachers3
ADD CONSTRAINT [File Imported must be formatted as JSON] CHECK (ISJSON(Teachers)=1)
GO
-- Insert JSON file
DECLARE @json NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.json', SINGLE_CLOB) AS JSONData)
INSERT INTO Teachers3 (Teachers)
SELECT @json
GO
SELECT * FROM Teachers3
GO
-- Try inserting a non-JSON file
DECLARE @csv NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.csv', SINGLE_CLOB) AS JSONData)
INSERT INTO Teachers3 (Teachers)
SELECT @csv
GO
SELECT * FROM Teachers3
GO
-- Store XML in XML column
DROP TABLE IF EXISTS Teachers4
GO
CREATE TABLE Teachers4 (
RecordID INT IDENTITY(1,1) PRIMARY KEY,
Teachers XML NOT NULL
)
GO
DECLARE @xml NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.xml', SINGLE_CLOB) AS XMLData)
INSERT INTO Teachers4 (Teachers)
VALUES (@xml)
GO
SELECT * FROM Teachers4
GO

-- Create a Schools database and two teachers tables
USE master
GO
DROP DATABASE IF EXISTS Schools
GO
CREATE DATABASE Schools
GO
USE Schools
GO
DROP TABLE IF EXISTS Teachers1
GO
CREATE TABLE Teachers1 (
RecordID INT IDENTITY(1,1) PRIMARY KEY,
Teachers XML NOT NULL
)
GO
DECLARE @xml NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.xml', SINGLE_CLOB) AS XMLData)
INSERT INTO Teachers1 (Teachers)
VALUES (@xml)
GO
DECLARE @json NVARCHAR(MAX) = (SELECT * FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.json', SINGLE_CLOB) AS JSONData)
SELECT *
INTO Teachers2
FROM OPENJSON(@json)
WITH (
  TeacherID INT,
  RoomID INT,
  FirstName NVARCHAR(50),
  LastName NVARCHAR(50)
)
GO

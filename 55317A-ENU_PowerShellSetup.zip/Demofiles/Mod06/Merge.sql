-- MERGE records, INSERTING or UPDATING records where appropriate
USE TempDB 
GO
DROP TABLE IF EXISTS CSVTeachers
GO
DROP TABLE IF EXISTS Teachers
GO
-- Create Source table with raw teacher data
SELECT * INTO CSVTeachers 
FROM OPENROWSET(BULK 'C:\Classfiles\Tools\teachers.csv', FORMATFILE='C:\Classfiles\Tools\teachers.fmt', FIRSTROW=2) AS CSV
GO
SELECT * FROM CSVTeachers
GO
--Create Target table with only partial list of teachers
CREATE TABLE Teachers (
TeacherID INT NOT NULL PRIMARY KEY,
RoomID INT NULL,
FirstName NVARCHAR(50) NOT NULL,
LastName NVARCHAR(50) NOT NULL
) 
GO
INSERT INTO Teachers (TeacherID,LastName,FirstName)  
VALUES (101,'Adams','J.'),
(102,'Madison','J.'),
(103,'Buren','M.')
GO
SELECT * FROM Teachers
GO
-- Update target table.  UPDATE existing records (MATCHED) with RoomID information.  INSERT new records (NOT MATCHED).  
MERGE INTO Teachers AS T
USING (SELECT TeacherID, RoomID, FirstName, LastName FROM CSVTeachers) AS C (TeacherID, RoomID, FirstName, LastName)
ON T.TeacherID = C.TeacherID
WHEN MATCHED THEN
UPDATE SET T.RoomID = C.RoomID
WHEN NOT Matched THEN
INSERT (TeacherID, RoomID, FirstName, LastName) VALUES (C.TeacherID, C.RoomID, C.FirstName, C.LastName);
GO
-- Verify that new records have been inserted.  Existing records should only have the RoomID updated.
SELECT * FROM Teachers
GO




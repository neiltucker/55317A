-- INSERT records into new or existing tables
USE AdventureWorks2019
GO
-- Use SELECT to insert records.  Create the table as a part of the insert operation.
SELECT BusinessEntityID, FirstName, LastName 
INTO contact1
FROM Person.Person
SELECT @@ROWCOUNT AS 'Number of Rows'
GO
SELECT * FROM contact1
GO
-- Use SELECT to insert records.  Create the table first and then insert records into it
CREATE TABLE dbo.contact2 (
BusinessEntityID INT NOT NULL PRIMARY KEY,
LastName VARCHAR(50) NOT NULL,
FirstName VARCHAR(50) NOT NULL
)
GO
INSERT INTO dbo.contact2
SELECT BusinessEntityID, LastName, FirstName FROM Person.Person
GO
SELECT * FROM contact2
GO
-- Use OPENROWSET to insert records into a table
SELECT * 
INTO dbo.Orders
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_order_data.csv',
FORMATFILE='C:\classfiles\tools\orders.fmt', FIRSTROW=2) AS Orders
SELECT @@ROWCOUNT AS 'Number of Rows'
GO
SELECT * FROM dbo.Orders
GO

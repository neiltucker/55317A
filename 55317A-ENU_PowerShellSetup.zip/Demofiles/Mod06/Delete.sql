-- Delete records using DELETE and TRUNCATE
USE TempDB 
GO
DROP TABLE IF EXISTS Classes
GO
DROP TABLE IF EXISTS Students
GO
CREATE TABLE Students (
StudentID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
StudentName NVARCHAR(50) NULL
) 
GO
INSERT INTO Students 
VALUES ('John'),
('Ian'),
('William')
GO
SELECT * FROM Students
GO
-- DELETE records using an incomplete transaction.  Test effect on table queries.
BEGIN TRANSACTION
DELETE FROM Students
-- COMMIT TRANSACTION
-- Query table before completing DELETE transaction.
SELECT * FROM Students
GO
-- Rollback the incomplete transaction so the standard query will work.
ROLLBACK
GO
SELECT * FROM Students
GO
-- DELETE all Records using a complete transaction.  Note effect on IDENTITY COLUMN
BEGIN TRANSACTION
DELETE FROM Students
COMMIT TRANSACTION
GO
INSERT INTO Students 
VALUES ('Jennifer'),
('Irene'),
('Wendy')
GO
SELECT * FROM Students
GO
-- TRUNCATE Table.  Note effect on IDENTITY COLUMN
TRUNCATE TABLE Students
GO
INSERT INTO Students 
VALUES ('Jack'),
('Ivan'),
('Wade')
GO
SELECT * FROM Students
GO
-- Use RESEED to reset IDENTITY values after DELETE operation.
-- Details of DELETE will be logged and IDENTITY will be reseeded.
DELETE FROM Students
GO
DBCC CHECKIDENT ('Students', RESEED, 0)
GO
INSERT INTO Students 
VALUES ('Jessica'),
('Ilene'),
('Winsome')
GO
SELECT * FROM Students
GO
-- Use TRY...CATCH blocks to implement your own error handling
-- Create a table that depends on the Student table
DROP TABLE IF EXISTS Classes
GO
CREATE TABLE Classes (
ClassID INT NOT NULL,
ClassName NVARCHAR(50) NULL,
StudentID INT,
CONSTRAINT FK_ID FOREIGN KEY (StudentID) REFERENCES dbo.Students (StudentID)
) 
GO
INSERT INTO Classes VALUES (101,'Mathematics',1)
GO
SELECT * FROM Classes
GO
-- Run the DELETE statement by itself to generate generic error message
-- TRUNCATE TABLE Students
DELETE Students 
GO
-- Run the DELETE statement with your own error handling using TRY...CATCH
BEGIN TRY
DELETE Students 
END TRY
BEGIN CATCH
PRINT 'Please verify that the table has no dependencies.'
END CATCH
GO


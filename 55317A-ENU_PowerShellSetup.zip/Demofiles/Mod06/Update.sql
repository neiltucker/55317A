-- Update records using Tables, Views and CTEs
USE master
GO
-- Create database, table and view
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'sales')
BEGIN
    DROP DATABASE sales
END
CREATE DATABASE sales
GO
USE sales
GO
CREATE TABLE [dbo].[sales](
    [ID] INT IDENTITY(1,1) PRIMARY KEY CLUSTERED,
	[CustomerID] [varchar](100) NULL,
	[StoreID] [varchar](100) NULL,
	[SalesDate] [varchar](100) NULL,
	[Sales] [varchar](100) NULL
) 
GO
USE sales
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_can.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_mex.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
INSERT INTO dbo.sales
SELECT CustomerID, StoreID, SalesDate, Sales
FROM OPENROWSET(BULK 'C:\classfiles\tools\raw_sales_data_usa.csv', FORMATFILE = 'C:\classfiles\tools\sales.fmt', FIRSTROW = 2) AS t;
GO
SELECT * FROM sales
GO
CREATE VIEW vUSAsales
AS
SELECT 
StoreID, CustomerID, Sales, SalesDate
FROM sales
WHERE StoreID LIKE 'usa%'
GO
SELECT * FROM vUSAsales
GO
-- Update records using a table
SELECT * FROM sales
WHERE StoreID = 'can91'
GO
UPDATE dbo.sales
SET Sales = ROUND(CAST(Sales as FLOAT) * .95, 0)
WHERE StoreID = 'can91'
SELECT @@ROWCOUNT AS 'Number of Rows'
GO
SELECT StoreID, Sales FROM sales
WHERE StoreID = 'can91'
GO
-- Update records using a CTE
WITH mex_sales AS 
(SELECT * FROM sales WHERE StoreID LIKE 'mex%')
SELECT * FROM mex_sales
WHERE StoreID = 'mex55'
GO
WITH mex_sales AS 
(SELECT * FROM sales WHERE StoreID LIKE 'mex%')
UPDATE mex_sales
SET Sales = ROUND(CAST(Sales as FLOAT) * 1.05, 0)
WHERE StoreID = 'mex55'
GO
WITH mex_sales AS 
(SELECT * FROM sales WHERE StoreID LIKE 'mex%')
SELECT * FROM mex_sales
WHERE StoreID = 'mex55'
GO
-- Update records using a VIEW
SELECT * FROM vUSAsales
WHERE SalesDate Between '2021-07-01' AND '2021-12-31'
GO
UPDATE vUSAsales
SET Sales = ROUND(CAST(Sales AS FLOAT) * 1.3, 0)
WHERE SalesDate Between '2021-07-01' AND '2021-12-31'
GO
SELECT * FROM vUSAsales
WHERE SalesDate Between '2021-07-01' AND '2021-12-31'
GO

-- Use a linked server connection to work with remote files
-- List of providers available on server: xp_enum_oledb_providers
-- If an error message for the provider Microsoft.ACE.OLEDB.16.0 appears, reinstall it using the following command:
-- xp_cmdshell 'C:\Classfiles\AccessDatabaseEngine_X64.exe /quiet'
-- EXECUTE sp_configure 'xp_cmdshell', 1 ; RECONFIGURE ;
USE master
GO
-- Excel File
EXEC sp_addlinkedserver 
@server = 'TeachersXLSX', 
@srvproduct='ACE 16', 
@provider='Microsoft.ACE.OLEDB.16.0', 
@datasrc='C:\Classfiles\Tools\teachers.xlsx', 
@provstr='Excel 12.0'
GO
SELECT * FROM TeachersXLSX...Sheet1$
GO
-- Excel file over the network
EXEC sp_addlinkedserver 
@server = 'TeachersXLSXNet', 
@srvproduct='ACE 16', 
@provider='Microsoft.ACE.OLEDB.16.0', 
@datasrc='\\55317MIASQL\Classfiles\Tools\teachers.xlsx', 
@provstr='Excel 12.0'
GO
SELECT * FROM TeachersXLSXNet...Sheet1$
GO
-- CSV File
EXEC sp_addlinkedserver 
@server = 'ToolsCSV', 
@srvproduct='ACE 16', 
@provider='Microsoft.ACE.OLEDB.16.0', 
@datasrc='C:\Classfiles\Tools\', 
@provstr='Text'
GO
SELECT * FROM ToolsCSV...[teachers#csv]
GO
-- CSV files over the network
EXEC sp_addlinkedserver 
@server = 'ToolsCSVNet', 
@srvproduct='ACE 16', 
@provider='Microsoft.ACE.OLEDB.16.0', 
@datasrc='\\55317MIASQL\Classfiles\Tools\',  -- The data source points to a folder.  All texts files in this location will be accessible.
@provstr='Text'
GO
SELECT * FROM ToolsCSVNET...[teachers#csv]
GO
SELECT * FROM ToolsCSVNET...[employees#csv]
GO
SELECT * FROM ToolsCSVNET...[customer#csv]
GO
-- INSERT records into linked tables
INSERT INTO ToolsCSVNET...[teachers#csv] 
VALUES('111','615','Dwight','Eisenhower')
GO
SELECT * FROM ToolsCSVNET...[teachers#csv]
GO
INSERT INTO TeachersXLSX...Sheet1$ 
VALUES('111','615','Dwight','Eisenhower')
GO
SELECT * FROM TeachersXLSX...Sheet1$
GO
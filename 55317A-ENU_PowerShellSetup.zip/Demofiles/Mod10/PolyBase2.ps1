﻿### Use PolyBase to connect to external tables
### Create Azurite Containers  (Note: Azurite using port 10000 by default for Blob services.)
$Context = New-AzStorageContext -Local
New-AzStorageContainer csvcontainer1 -Permission Container -Context $Context
New-AzStorageContainer csvcontainer2 -Permission Off -Context $Context

# Upload teachers.csv to csvcontainer1
$Blob1 = @{
  File             = 'C:\Classfiles\Tools\teachers.csv'
  Container        = 'csvcontainer1'
  Blob             = "teachers.csv"
  Context          = $Context
  StandardBlobTier = 'Hot'
}
$Teachers = Set-AzStorageBlobContent @Blob1
$Teachers | Format-List
  
# Upload employees.csv to csvcontainer1
$Blob2 = @{
 File             = 'C:\Classfiles\Tools\employees.csv'
 Container        = 'csvcontainer1'
 Blob             = 'employees.csv'
 Context          = $Context
 StandardBlobTier = 'Hot'
}
$Employees = Set-AzStorageBlobContent @Blob2
$Employees | FL
  
# Upload customer.csv to csvcontainer2 and rename to customers.csv
$Blob3 = @{
 File             = 'C:\Classfiles\Tools\customer.csv'
 Container        = 'csvcontainer2'
 Blob             = 'customers.csv'
 Context          = $Context
 StandardBlobTier = 'Hot'
}
$Customers = Set-AzStorageBlobContent @Blob3
$Customers | fl

# Upload teachers.fmt to csvcontainer1
$Blob4 = @{
  File             = 'C:\Classfiles\Tools\teachers.fmt'
  Container        = 'csvcontainer1'
  Blob             = "teachers.fmt"
  Context          = $Context
  StandardBlobTier = 'Hot'
}
Set-AzStorageBlobContent @Blob4

# View container & blob information using PowerShell
Get-AzStorageContainer -Context $Context -Name "csvcontainer1"
Get-AzStorageBlob -Context $Context -Container "csvcontainer1" -Blob "*"
Get-AzStorageContainer -Context $Context -Name "csvcontainer2"
Get-AzStorageBlob -Context $Context -Container "csvcontainer2" -Blob "*"

# Download the files using PowerShell
Get-AzStorageBlobContent -Context $Context -Container "csvcontainer1" -Blob "teachers.csv" -Destination $Destination
Get-AzStorageBlobContent -Context $Context -Container "csvcontainer1" -Blob "employees.csv" -Destination $Destination
Get-AzStorageBlobContent -Context $Context -Container "csvcontainer2" -Blob "customers.csv" -Destination $Destination
  
# Download files using their blob URL
# The customers.csv file will be inaccessible because the csvcontainer2 container was created with public permissions disabled.
$Destination = "C:\Classfiles"
Set-Location $Destination
Invoke-WebRequest -UseBasicParsing -URI http://127.0.0.1:10000/devstoreaccount1/csvcontainer1/teachers.csv -OutFile teachers.csv
Invoke-WebRequest -UseBasicParsing -URI http://127.0.0.1:10000/devstoreaccount1/csvcontainer1/employees.csv -OutFile employees.csv
Invoke-WebRequest -UseBasicParsing -URI http://127.0.0.1:10000/devstoreaccount1/csvcontainer2/customers.csv  -OutFile customers.csv




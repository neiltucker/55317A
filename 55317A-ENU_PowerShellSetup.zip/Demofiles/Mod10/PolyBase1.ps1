### Use PolyBase to connect to external tables
### Use Azurite to emulate Microsoft Azure Storage
New-Item C:\Azurite -ItemType Directory -ErrorAction SilentlyContinue
Set-Location C:\Azurite
azurite --skipApiVersionCheck --location c:\azurite --debug c:\azurite\debug.log

﻿$vscode = "https://code.visualstudio.com/sha/download?build=stable&os=win32-x64"
Set-Location C:\Temp
Invoke-WebRequest -UseBasicParsing -URI $vscode -OutFile c:\temp\vscodesetup.exe
c:\temp\vscodesetup.exe /SILENT /MERGETASKS=!runcode,desktopicon,addcontextmenufiles,addcontextmenufolders /LOG=C:\temp\vscodesetup.log /NORESTART
Start-Sleep 15


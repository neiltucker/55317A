# Install Node.js 
scoop install nodejs-lts --global

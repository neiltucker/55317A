#  "*****   Change the default location of new data and log files   *****"
invoke-sqlcmd "exec xp_instance_regwrite 'HKEY_LOCAL_MACHINE', 'Software\Microsoft\MSSQLServer\MSSQLServer', 'DefaultData', REG_SZ,'E:\Data\'"
invoke-sqlcmd "exec xp_instance_regwrite 'HKEY_LOCAL_MACHINE', 'Software\Microsoft\MSSQLServer\MSSQLServer', 'DefaultLog', REG_SZ,'F:\Log\'"

#  "*****   Modify the size and auto-grow settings for the Model database   *****"
invoke-sqlcmd -InputFile D:\Labfiles\Modify_ModelDB.sql

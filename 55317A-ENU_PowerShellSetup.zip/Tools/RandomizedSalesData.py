# This script will create a "Sales Table" dataset and exports the rows to a CSV file.
# Change the rows variable to control the number of rows exported.

### This looping operation will install the modules not already configured.
import importlib, os, sys
packages = ['numpy', 'pandas']
for package in packages:
  try:
    module = importlib.__import__(package)
    globals()[package] = module
  except ImportError:
    cmd = 'pip install --user ' + package
    os.system(cmd)
    module = importlib.__import__(package)

rows = 1000
import random, decimal, string, csv, datetime, numpy as np, pandas as pd
location = 'usa'
filename = 'raw_sales_data_' + location + '.csv'
customers = pd.read_csv('raw_customer_data.csv')
ucid = np.unique(customers['CustomerID'])
lucid = list(ucid)
i = 0
customerid = []
while i < rows:
  customerid.append(random.choice(lucid))
  i += 1

storeid = np.array([location + ''.join(random.choice(string.digits) for _ in range(2)) for _ in range(rows)])
now = datetime.date.today()
salesdate = np.array([now - datetime.timedelta(days=(random.randint(360,420))) for _ in range(rows)])
sales = np.array([random.randint(500,10000) for _ in range(rows)])
orderdata1 = list(zip(customerid,storeid,salesdate,sales))
df = pd.DataFrame(orderdata1)
df.to_csv(filename,index=False,header=["CustomerID","StoreID","SalesDate","Sales"])




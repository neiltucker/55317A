-- NYCTaxi Lab: Using Python and R in SQL Server
-- SQL Server Machine Learning Services must already be installed
-- External scriptures should be enabled (e.g., EXECUTE sp_configure  'external scripts enabled', 1)
-- Make sure the NYCTaxi_Sample database is already installed (c:\classfiles\tools\nyctaxi_install.ps1)

USE NYCTaxi_Sample
GO
-- Verify Python script execution
EXECUTE sp_execute_external_script @language = N'Python'
 , @script = N'
x = 10
y = 20
z = x * y
print(z)
'

-- Query nyctaxi_sample table
SELECT TOP(5) * FROM nyctaxi_sample
SELECT COUNT(*) as [Number of Rows] FROM nyctaxi_sample
GO


-- Get a summary on the table
SELECT DISTINCT [Passenger_Count], ROUND (SUM ([fare_amount]),0) as [Total_Fares], ROUND (AVG ([fare_amount]),0) as [Average_Fares]
FROM nyctaxi_sample
GROUP BY [Passenger_Count]
ORDER BY  [Average_Fares] 
GO


-- Create a Python Stored Procedure
DROP PROCEDURE IF EXISTS PyPlotMatplotlib;
GO
CREATE PROCEDURE [dbo].[PyPlotMatplotlib]
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @query nvarchar(max) =
    N'SELECT cast(tipped as int) as tipped, tip_amount, fare_amount FROM [dbo].[nyctaxi_sample]'
    EXECUTE sp_execute_external_script
    @language = 'Python',
    @script = N'
import pickle
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

fig_handle = plt.figure()
plt.hist(InputDataSet.tipped)
plt.xlabel("Tipped")
plt.ylabel("Counts")
plt.title("Histogram, Tipped")
plot0 = pd.DataFrame(data =[pickle.dumps(fig_handle)], columns =["plot"])
plt.clf()

plt.hist(InputDataSet.tip_amount)
plt.xlabel("Tip amount ($)")
plt.ylabel("Counts")
plt.title("Histogram, Tip amount")
plot1 = pd.DataFrame(data =[pickle.dumps(fig_handle)], columns =["plot"])
plt.clf()

plt.hist(InputDataSet.fare_amount)
plt.xlabel("Fare amount ($)")
plt.ylabel("Counts")
plt.title("Histogram, Fare amount")
plot2 = pd.DataFrame(data =[pickle.dumps(fig_handle)], columns =["plot"])
plt.clf()

plt.scatter( InputDataSet.fare_amount, InputDataSet.tip_amount)
plt.xlabel("Fare Amount ($)")
plt.ylabel("Tip Amount ($)")
plt.title("Tip amount by Fare amount")
plot3 = pd.DataFrame(data =[pickle.dumps(fig_handle)], columns =["plot"])
plt.clf()

OutputDataSet = plot0.append(plot1, ignore_index=True).append(plot2, ignore_index=True).append(plot3, ignore_index=True)
',
@input_data_1 = @query
WITH RESULT SETS ((plot varbinary(max)))
END
GO


-- Execute the Procedure
EXECUTE PyPlotMatplotlib


﻿$resourceGroupName = 'init070236rg'
$osDiskName = '55317newdisk'
$osDisk = Get-AzDisk -ResourceGroupName $resourceGroupName -DiskName $osDiskName
$DiskSizeInGB = "64"
$ResourceGroup = Get-AzResourceGroup -Name $ResourceGroupName
$Location = $ResourceGroup.Location

### Network Setup
$subnetName = '192_168_10'
$singleSubnet = New-AzVirtualNetworkSubnetConfig -Name $subnetName -AddressPrefix 192.168.10.0/24
$virtualNetwork = New-AzVirtualNetwork -Name "gen55317vnet2" -ResourceGroupName $ResourceGroupName -Location $ResourceGroup.Location -AddressPrefix 192.168.0.0/16 -Subnet $SingleSubnet
$vnet = $virtualNetwork

# Network Security Group
$nsgName = "myNsg"
$rdpRule = New-AzNetworkSecurityRuleConfig -Name myRdpRule -Description "Allow RDP" `
    -Access Allow -Protocol Tcp -Direction Inbound -Priority 110 `
    -SourceAddressPrefix Internet -SourcePortRange * `
    -DestinationAddressPrefix * -DestinationPortRange 3389
$nsg = New-AzNetworkSecurityGroup `
   -ResourceGroupName $ResourceGroupName `
   -Location $location `
   -Name $nsgName -SecurityRules $rdpRule
# Network Card and Public IP
$ipName = "PublicIP"
$pip = New-AzPublicIpAddress -Name $ipName -ResourceGroupName $ResourceGroupName -Location $Location -AllocationMethod Dynamic
$nicName = "55317nic"
$nic = New-AzNetworkInterface -Name $nicName -ResourceGroupName $ResourceGroupName -Location $Location -SubnetId $vnet.Subnets[0].Id -PublicIpAddressId $pip.Id -NetworkSecurityGroupId $nsg.Id

### Configure VM
$vmName = "55317MIASQL"
$vmConfig = New-AzVMConfig -VMName $vmName -VMSize "Standard_D2_v2"
$vm = Add-AzVMNetworkInterface -VM $vmConfig -Id $nic.Id
$vm = Set-AzVMOSDisk -VM $vm -ManagedDiskId $osDisk.Id -StorageAccountType Standard_LRS -DiskSizeInGB $DiskSizeInGB -CreateOption Attach -Windows
New-AzVM -ResourceGroupName $ResourceGroupName -Location $Location -VM $vm

$vm = $Null



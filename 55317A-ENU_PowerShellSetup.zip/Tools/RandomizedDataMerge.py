### Join the Orders and Customers raw data tables

import pandas as pd

customers = pd.read_csv('raw_customer_data.csv')
orders = pd.read_csv('raw_order_data.csv')

merge = pd.merge(customers,orders, on='CustomerID', how='inner')

merge.to_csv('raw_merged_data.csv',index=False)










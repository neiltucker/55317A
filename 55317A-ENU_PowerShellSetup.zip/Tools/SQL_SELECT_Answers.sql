-- Use the 55317AzureDatabase.ps1 script to create an Azure Database for these queries.  It is in the "Tools" folder.
-- The script will create a text file (55317AzureDatabase[DateTime].txt) that will specify the name of the database and server created

-- 1 List all employees using the columns EmployeeID, DateOfBirth, FirstName, LastName
Select EmployeeID, DateOfBirth, FirstName, LastName From employees


-- 2 Sort the records by salary in descending order
Select EmployeeID, DateOfBirth, FirstName, LastName, Salary From employees
Order By salary desc


-- 3 Find the employee that is paid the most
Select Top 1 With Ties EmployeeID, max(Salary) From Employees
Group By EmployeeID
Order By max(salary) Desc


-- 4 List the minimum, maximum and average salaries
Select MIN(Salary) as Minimum_Salary, MAX(Salary) as Maximum_Salary, AVG(Salary) as Average_Salary From Employees


-- 5 Find the oldest and youngest employees
Select Top 1 With Ties EmployeeID, max(DateOfBirth)as "Date Of Birth" From Employees
Group By EmployeeID
Order By max(DateOfBirth)


-- 6 Find the employee with the longest work history
Select emp1.EmployeeID, emp1.FirstName, emp1.LastName, emp1.HireDate From Employees as emp1 
Join (Select top 1 min(hiredate) as hiredate from employees) as emp2
ON emp1.hiredate = emp2.hiredate


-- 7 List the 10 highest paid employees
Select Top 10 EmployeeID, FirstName, LastName, Salary From Employees
Order By Salary DESC


-- 8 Find out how many employees belong to the department with an ID of 5
Select count(DepartmentID) as "Number of Employees in Department 5" From Employees
Where DepartmentID = 5


-- 9 Sort the employees based on their hire date, showing the newest employees first
Select EmployeeID, FirstName, LastName, HireDate From EMployees
Order By HireDate desc


-- 10 Find out how many employees work in location 7
Select count(LocationID) as "Number of Employees in Location 7" From Employees
Where LocationID = 7















﻿### Install Python on the local computer (File #2)
### Must be run from an Administrator Console

### Upgrade pip
python -m pip install --upgrade pip

### Install Python modules using pip.  A new PowerShell Administrator console should be opened to run this command.
pip install --upgrade pandas scipy matplotlib pyodbc faker

### Verify installed modules
# pip list


﻿### Query SQL Server objects using PowerShell
# 1. Import SQL Server module and connect to local SQL Server
Import-Module SQLServer
Set-Location SQLServer:

# 2. List SQLServer module cmdlets
Get-Command -Module SQLServer
(Get-Command -Module SQLServer).Length

# 3. Invoke-Sqlcmd to get connection details
Invoke-Sqlcmd -Query "SELECT SUSER_NAME() AS [User Name], @@SERVERNAME AS [SQLServer Instance], DB_Name() as [Database Name]"

# 4. Get database information
Get-SqlDatabase -ServerInstance '55317MIASQL' 
Get-SqlDatabase -ServerInstance '55317MIASQL' -Name AdventureWorks2019 

# 5. Get table data
Read-SqlTableData -ServerInstance 55317MIASQL -DatabaseName AdventureWorks2019 -SchemaName Sales -TableName Customer -TopN 10
Read-SqlTableData -ServerInstance 55317MIASQL -DatabaseName AdventureWorks2019 -SchemaName Person -TableName Person -TopN 10 -ColumnName BusinessEntityID,FirstName,LastName

# 6. Get view data
Read-SqlViewData -ServerInstance 55317MIASQL -DatabaseName AdventureWorks2019 -SchemaName Sales -ViewName vSalesPerson
Read-SqlViewData -ServerInstance 55317MIASQL -DatabaseName AdventureWorks2019 -SchemaName HumanResources -ViewName vEmployee
Read-SqlViewData -ServerInstance 55317MIASQL -DatabaseName AdventureWorks2019 -SchemaName HumanResources -ViewName vEmployee -ColumnName BusinessEntityID,Firstname,LastName,PhoneNumber
Read-SqlViewData -ServerInstance 55317MIASQL -DatabaseName AdventureWorks2019 -SchemaName HumanResources -ViewName vEmployee -ColumnName BusinessEntityID,Firstname,LastName,PhoneNumber -ColumnOrder BusinessEntityID

# 7. Invoke-Sqlcmd to get database information
Invoke-Sqlcmd -Query "SELECT * FROM sys.databases"
Invoke-Sqlcmd -Query "SELECT name,database_id FROM sys.databases"
Invoke-Sqlcmd -Query "SELECT name,database_id FROM sys.databases WHERE name = 'AdventureWorks2019'"

# 8. Invoke-Sqlcmd to get table data
Invoke-Sqlcmd -Query "SELECT TOP 10 * FROM AdventureWorks2019.Sales.Customer"
Invoke-Sqlcmd -Query "SELECT TOP 10 BusinessEntityID as [ID], FirstName, LastName FROM AdventureWorks2019.Person.Person"

# 9. Change database location
Invoke-Sqlcmd -Query "SELECT DB_Name() as [Database Name]"
Set-Location SQLSERVER:\SQL\55317MIASQL\DEFAULT\Databases
Get-ChildItem
Set-Location SQLSERVER:\SQL\55317MIASQL\DEFAULT\Databases\AdventureWorks2019
Get-ChildItem
Invoke-Sqlcmd -Query "SELECT DB_Name() as [Database Name]"

# 10. Invoke-Sqlcmd to get view data
Invoke-Sqlcmd -Query "SELECT * FROM Sales.vSalesPerson"
Invoke-Sqlcmd -Query "SELECT * FROM HumanResources.vEmployee"
Invoke-Sqlcmd -Query "SELECT BusinessEntityID,Firstname,LastName,PhoneNumber FROM HumanResources.vEmployee"
Invoke-Sqlcmd -Query "SELECT BusinessEntityID,Firstname,LastName,PhoneNumber FROM HumanResources.vEmployee ORDER BY BusinessEntityID"

# 11. Export View to CSV file.  View file in Notepad to verify export succeeded.
Invoke-Sqlcmd -Query "SELECT BusinessEntityID,Firstname,LastName,PhoneNumber FROM HumanResources.vEmployee ORDER BY BusinessEntityID" | Export-Csv -Path C:\Classfiles\vEmployee.csv -NoTypeInformation

# 12. Run a script using Invoke-Sqlcmd to recreate the Schools database.  Verify all connections to the existing Schools database are removed first.
# Note: New databases should always be created from the context of the Master system database.
Set-Location SQLSERVER:\SQL\55317MIASQL\DEFAULT\Databases\Master
Invoke-Sqlcmd -InputFile C:\Classfiles\Demofiles\Mod09\Schools.sql
Set-Location SQLSERVER:\SQL\55317MIASQL\DEFAULT\Databases
Get-ChildItem
Set-Location SQLSERVER:\SQL\55317MIASQL\DEFAULT\Databases\Schools
Get-ChildItem

# 12. Query a table directly from its folder
Set-Location Tables
Get-ChildItem
Read-SqlTableData dbo.Teachers2

# 13. Create an Employees table in the Schools database 
Set-Location SQLSERVER:\SQL\55317MIASQL\DEFAULT\Databases\Schools\Tables
Get-ChildItem
Invoke-SQLcmd -Query "DROP TABLE IF EXISTS dbo.Employees"
Invoke-SQLcmd -Query "CREATE TABLE dbo.Employees (BusinessEntityID VARCHAR(50),FirstName VARCHAR(50),LastName VARCHAR(50),PhoneNumber VARCHAR(50))"
Get-ChildItem

# 14. Import records from the employees.csv file to the new Employees table
Import-Csv -Path C:\Classfiles\vEmployee.csv | Write-SqlTableData -ServerInstance "55317MIASQL" -DatabaseName "Schools" -SchemaName "dbo" -TableName "Employees" 
Read-SqlTableData dbo.Employees
(Read-SqlTableData dbo.Employees).Length

# 15. Import records and create the table at the same time by adding the "-Force" parameter to Write-SqlTableData
Import-Csv -Path C:\Classfiles\vEmployee.csv | Write-SqlTableData -ServerInstance "55317MIASQL" -DatabaseName "Schools" -SchemaName "dbo" -TableName "Employees2" -Force
Get-ChildItem
Read-SqlTableData dbo.Employees2

# 16. If time permits, use the PowerShell cmdlets above to create a table named Customers from the C:\Classfiles\Tools\customer.csv file.  Query the table after creation. 

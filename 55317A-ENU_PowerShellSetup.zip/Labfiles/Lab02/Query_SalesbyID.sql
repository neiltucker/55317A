SELECT BusinessEntityID AS ID, ROUND(SalesYTD, 2) AS SalesYTD
FROM [AdventureWorks2019].[Sales].[vSalesPerson]
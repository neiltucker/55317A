-- Create and use stored procedures
USE Sales
GO
DROP PROCEDURE IF EXISTS uspCustomerSales
GO
CREATE PROCEDURE uspCustomerSales (@CustomerID VARCHAR(10) = '%')
AS
SELECT CustomerID, SUM(CAST(Sales as INT)) as [Total Sales]
FROM Sales
WHERE CustomerID LIKE @CustomerID
GROUP BY CustomerID
ORDER BY CustomerID
GO
DROP PROCEDURE IF EXISTS uspStoreSales
GO
CREATE PROCEDURE uspStoreSales
WITH EXECUTE AS 'sqllogin2'  --sqllogin2 will need read permissions on the Sales table
AS
BEGIN
SELECT StoreID, SUM(CAST(Sales as INT)) as [Total Sales]
FROM Sales
GROUP BY StoreID
ORDER BY StoreID
END
GO
DROP PROC IF EXISTS uspSquare 
GO
CREATE PROCEDURE uspSquare (@number INT = 1)
AS
BEGIN
DECLARE @square INT 
SET @square = CAST(@number as INT) * CAST(@number as INT)
SELECT @square as 'Square'
END
GO
-- Grant permissions to procedures
-- First grant access to database
DROP USER IF EXISTS sqllogin1
GO
CREATE USER sqllogin1 FOR LOGIN sqllogin1
GO
GRANT EXECUTE ON SCHEMA::dbo TO sqllogin1
GO
DROP USER IF EXISTS sqllogin2
GO
CREATE USER sqllogin2 FOR LOGIN sqllogin2
GO
GRANT EXECUTE ON SCHEMA::dbo TO sqllogin2
GO
DENY EXECUTE ON OBJECT::dbo.uspSquare TO sqllogin2
GO
-- Execute procedures
-- Create a new Query Editor window and login with SQL Authentication as sqllogin1 with a password of Pa$$w0rd
-- Copy the code in this section to the new window and execute it as sqllogin1
-- Create a new Query Editor window and login with SQL Authentication as sqllogin2 with a password of Pa$$w0rd
-- Copy the code in this section to the new window and execute it as sqllogin2
USE sales
GO
EXECUTE uspCustomerSales
GO
EXECUTE uspCustomerSales 'BG96'
GO
EXECUTE uspStoreSales
GO
EXEC uspSquare
GO
EXECUTE uspSquare 15
GO
-- Identify which procedures work for which user and why
-- Modify the permissions so all procedures work for all users.
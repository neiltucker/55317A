-- Use PolyBase to query Blob files
-- Verify PolyBase is installed and configured
USE master
GO
SELECT SERVERPROPERTY ('IsPolyBaseInstalled') AS IsPolyBaseInstalled
GO
EXECUTE sp_configure @configname = 'polybase enabled', @configvalue = 1
RECONFIGURE
GO
-- Create database and master key 
CREATE DATABASE PolyBaseDemo
GO
USE PolyBaseDemo
GO
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Pa$$w0rd'
GO
-- Create external data source and file format
IF EXISTS (SELECT * FROM sys.external_data_sources WHERE name = 'Blob_DS2')
DROP EXTERNAL DATA SOURCE Blob_DS2
GO
CREATE EXTERNAL DATA SOURCE Blob_DS2
WITH
(
 LOCATION = 'abs://55xxx.blob.core.windows.net/labfiles'
)
GO
CREATE EXTERNAL FILE FORMAT CSVFormat
WITH (
FORMAT_TYPE = DELIMITEDTEXT, 
FORMAT_OPTIONS (
    FIELD_TERMINATOR = ',', 
	STRING_DELIMITER = '"', 
	FIRST_ROW = 2)
)
GO
SELECT * FROM OPENROWSET(
   BULK '/teachers.csv',
   DATA_SOURCE = 'Blob_DS2',
   FORMAT = 'CSV',
   FIRSTROW = 2
   ) 
WITH (
    TeacherID varchar(50),
    RoomID varchar(50),
    FirstName varchar(50),
	LastName varchar(50)
) AS TeachersCSV
GO

-- Create external table
IF EXISTS (SELECT * FROM sys.external_tables WHERE name = 'teachersblob')
DROP EXTERNAL TABLE teachersblob
GO
CREATE EXTERNAL TABLE dbo.teachersblob (
    TeacherID varchar(50) NOT NULL,
    RoomID varchar(50) NOT NULL,
    FirstName varchar(50) NOT NULL,
	LastName varchar(50) NOT NULL
)
WITH (
    LOCATION='/teachers.csv',
    DATA_SOURCE = Blob_DS2,
	FILE_FORMAT = CSVFormat
)
GO
SELECT * FROM teachersblob 
GO
-- Access S3 blob
IF EXISTS (SELECT * FROM sys.external_data_sources WHERE name = 'Blob_DS3')
DROP EXTERNAL DATA SOURCE Blob_DS3
GO
CREATE EXTERNAL DATA SOURCE Blob_DS3
WITH
(
 LOCATION = 's3://55xxx.s3.amazonaws.com'
)
GO
SELECT * FROM OPENROWSET(
   BULK '/teachers.csv',
   DATA_SOURCE = 'Blob_DS3',
   FORMAT = 'CSV',
   FIRSTROW = 2
   ) 
WITH (
    TeacherID varchar(50),
    RoomID varchar(50),
    FirstName varchar(50),
	LastName varchar(50)
) AS TeachersCSV
GO
-- Create external table
IF EXISTS (SELECT * FROM sys.external_tables WHERE name = 'teachersblobS3')
DROP EXTERNAL TABLE teachersblobS3
GO
CREATE EXTERNAL TABLE dbo.teachersblobS3 (
    TeacherID varchar(50) NOT NULL,
    RoomID varchar(50) NOT NULL,
    FirstName varchar(50) NOT NULL,
	LastName varchar(50) NOT NULL
)
WITH (
    LOCATION='/teachers.csv',
    DATA_SOURCE = Blob_DS3,
	FILE_FORMAT = CSVFormat
)
GO
SELECT * FROM teachersblobS3 
GO

# Update the PowerShell Help Files on the server
Start-Process powershell.exe -Verb RunAs -ArgumentList "-Command Update-Help", "-SourcePath C:\Classfiles\PSHelp", "-Force"
Start-Process powershell.exe -Verb RunAs -ArgumentList "-Command Update-Help -Force"









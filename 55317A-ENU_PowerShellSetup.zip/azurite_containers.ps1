# Create Azurite Containers
$Context = New-AzStorageContext -Local
New-AzStorageContainer csvblob1 -Permission Container -Context $Context
New-AzStorageContainer csvblob2 -Permission Off -Context $Context

# upload teachers.csv
$Blob1 = @{
  File             = 'C:\Classfiles\Tools\teachers.csv'
  Container        = 'csvblob1'
  Blob             = "teachers.csv"
  Context          = $Context
  StandardBlobTier = 'Hot'
}
Set-AzStorageBlobContent @Blob1
  
# upload employees.csv
$Blob2 = @{
 File             = 'C:\Classfiles\Tools\employees.csv'
 Container        = 'csvblob1'
 Blob             = 'employees.csv'
 Context          = $Context
 StandardBlobTier = 'Hot'
}
Set-AzStorageBlobContent @Blob2
  
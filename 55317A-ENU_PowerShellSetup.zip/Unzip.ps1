# Unzip Setup Files
$Archive = "c:\labfiles.55317\55317A-ENU_PowerShellSetup.zip"
$LabFolder = "c:\labfiles.55317\"
$LabCmd = "c:\labfiles.55317\run.cmd"
Expand-Archive $Archive $LabFolder
<# Old Unzip Method
$File = New-Object -Com Shell.Application
$Zip = $File.Namespace($Archive)
$Unzip = 'ForEach ($Item in $Zip.Items()) {$File.Namespace($LabFolder).CopyHere($Item)}'
If (![System.IO.File]::Exists($LabCmd)) {Invoke-Expression $Unzip}
#>

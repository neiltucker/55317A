# Install Scoop
# Invoke-RestMethod get.scoop.sh | Invoke-Expression
Invoke-Expression "& {$(Invoke-RestMethod get.scoop.sh)} -RunAsAdmin"

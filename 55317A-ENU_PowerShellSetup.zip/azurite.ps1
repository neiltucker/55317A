# Install and Configure Azurite
npm install -g azurite
New-Item C:\Azurite -Type Directory 
Copy-Item -Path "C:\Classfiles\Tools\*.csv" -Destination "C:\Azurite" 
# azurite --silent --location c:\azurite --debug c:\azurite\debug.log

# Install PowerShell Az Module
Start-Process powershell.exe -Verb RunAs -ArgumentList "-Command Install-Module", "-Name Az", "-Scope AllUsers", "-Repository PSGallery", "-Force"


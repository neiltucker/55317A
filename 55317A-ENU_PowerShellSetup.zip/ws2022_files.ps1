Remove-Item $Labfiles\Sources -Recurse -Force -ErrorAction SilentlyContinue
DisMount-Diskimage -DevicePath \\.\CDROM0 -ErrorAction SilentlyContinue
DisMount-Diskimage -DevicePath \\.\CDROM1 -ErrorAction SilentlyContinue
New-Item -ItemType "Directory" -Path $Labfiles\Sources\Sxs -Force
$SRVImage = Mount-DiskImage $SRVISO 
$SRVPath = $SRVImage.DevicePath
$SRVDrive = $SRVPath.Substring(4,6)
Copy-Item -Path $SRVPath"\"\Sources\sxs -Destination $Labfiles\Sources -Recurse -Force
DisMount-DiskImage -DevicePath $SRVPath 


# Download Adventureworks DW Database
Write-Output "Download AdventureWorksDW backup files"
$WorkFolder = "C:\classfiles\tools\"
$AdventureWorksDB = "AdventureworksDW2019.bak"
$AdventureWorksDBPATH = $WorkFolder + $AdventureWorksDB 
$AdventureWorksURL = "https://github.com/Microsoft/sql-server-samples/releases/download/adventureworks/" + $AdventureWorksDB

Invoke-WebRequest -Uri $AdventureworksURL -OutFile $AdventureWorksDBPATH
Start-Sleep 5
IF (Test-Path $AdventureWorksDBPATH) {
Write-Output "Adventureworks DB downloaded successfully."}
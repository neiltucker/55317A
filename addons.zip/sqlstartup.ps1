Set-Service -Name 'SQLSERVERAGENT' -StartupType Automatic
Set-Service -Name 'MSSQLLaunchpad' -StartupType Automatic
Start-Service -Name 'SQLSERVERAGENT' 
Start-Service -Name 'MSSQLLaunchpad'
